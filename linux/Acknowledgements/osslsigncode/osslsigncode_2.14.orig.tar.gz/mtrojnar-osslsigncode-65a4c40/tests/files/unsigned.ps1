cls
Write-Host "żółć"